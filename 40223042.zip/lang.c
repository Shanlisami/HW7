//40223042 Shanli Samienezhad
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    int n;
    printf("n:\n");
    scanf("%d", &n);

    char lan1[n][100];
    char lan2[n][100];

    int i;

    for( i = 0 ; i < n ; i++ ) 
    {
        printf("write word %d with one space between:\n", i+1);
        scanf("%s %s", lan1[i], lan2[i]);
    }

    /*for(i = 0 ; i < n ; i++)
    {
        lan1[i][strlen(lan1[i])] = '\0';
        lan2[i][strlen(lan2[i])] = '\0';
    }*/
    /*for( i = 0 ; i < n ; i++ )
    {
        printf("%s\n", lan1[i]);
        printf("%s\n", lan2[i]);
    }*/

    getchar();

    char sentence[100];
    printf("type the sentence:\n");
    fgets( sentence , 100 , stdin );

    /*for( i = 0 ; i < 25 ; i++ )
    {
        printf(" %d = %c\n", i+1 , sentence[i]);
    }*/

    if( tolower(lan1[0][0]) == lan1[0][0] )
    {
        for( i = 0 ; i < 100 ; i++ )
        {
            sentence[i] = tolower(sentence[i]);
        }
    }

    else
    {
        for( i = 0 ; i < 100 ; i++ )
        {
            sentence[i] = toupper(sentence[i]);
        }
    }

    //printf("%s", sentence); ta inja halle

    char test[100];
    int j;
    int andaze = 0;
    int makan = 0;

    while(sentence[makan])
    {
        for( j = 0 ; j < n ; j++ ) //lan1 satr ha
        {
            int flag = 1;

            for( i = 0 ; i < strlen(lan1[j]) ; i++ ) //be andaze tedad char har satr
            {
                test[i] = sentence[i+andaze];
            }

            //test[i+1] = '\0';
            //printf("test=%s\n", test);
            //printf("lan1[%d]=%s\n", j , lan1[j]);
            //printf("andaze=%d\n", andaze);
            //printf("%d\n", test == lan1[j]);

            int k; //strcmp
            int ifsame = 1;

            for( k = 0 ; k < strlen(lan1[j]) ; k++ )
            {
                if( test[k] != lan1[j][k] )
                {
                    ifsame = 0;
                }
            }

            if( ifsame ) //age yeki bud
            {
                makan += (strlen(lan1[j])+1);

                if( strlen(lan1[j]) > strlen(lan2[j]) )
                {
                    if( !sentence[makan] )
                    {
                        printf("%s\n", lan2[j]);
                    }

                    //printf("ans=%s\n", lan2[j]);

                    else
                    {
                        printf("%s ", lan2[j]);
                    }
                }

                else
                {
                    if( !sentence[makan] )
                    {
                        printf("%s\n", lan1[j]);
                    }

                    //printf("ans=%s\n", lan1[j]);

                    else
                    {
                       printf("%s ", lan1[j]);
                    }
                }

                flag = 0;
            }

            if( flag == 0 )
            {
                andaze += strlen(lan1[j])+1; //+1 baraye fasele
            }
        }
    }
}